1. Python 3.11 is used for the assignment.

2. How to run:
    python 19.py input.txt output.txt 1
    python 19.py input.txt output.txt 2

3. input.txt : This is the input file where first 3 lines correspond to  initial_state 
    and the next 3 line are for goal_state.

4. output.txt : Output is printed in this file.

5. The third command line argument is a number 1 or 2 
    1 is for 1st heuristic
    2 is for 2nd heuristic